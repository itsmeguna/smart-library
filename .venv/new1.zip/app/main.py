# app/main.py

from fastapi import FastAPI
from app.routes import auth

app = FastAPI()
#hello
app.include_router(auth.router)
