from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.schemas import BorrowRequest, BorrowedBookOut
from app.auth_utils import get_current_user
from app.crud import user_crud

router = APIRouter(prefix="/user", tags=["Users"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/borrow", response_model=BorrowedBookOut)
def borrow_book(
    req: BorrowRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    return user_crud.borrow_book(db, user_id=current_user["id"], book_id=req.book_id)
