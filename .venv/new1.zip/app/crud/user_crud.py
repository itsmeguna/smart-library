from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from app import models

def borrow_book(db: Session, user_id: int, book_id: int):
    # 1. Getting book
    book = db.query(models.Book).filter(models.Book.id == book_id).first()
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    if book.copies_available < 1:
        raise HTTPException(status_code=400, detail="No copies available")

    # 2. Checking limit
    active_borrows = db.query(models.BorrowedBook).filter(
        models.BorrowedBook.user_id == user_id,
        models.BorrowedBook.return_date == None
    ).count()
    if active_borrows >= 3:
        raise HTTPException(status_code=400, detail="Borrowing limit reached")

    # 3. Check for overdue
    overdue = db.query(models.BorrowedBook).filter(
        models.BorrowedBook.user_id == user_id,
        models.BorrowedBook.return_date == None,
        models.BorrowedBook.due_date < datetime.utcnow()
    ).first()
    if overdue:
        raise HTTPException(status_code=403, detail="You have overdue books")

    # 4. Create borrow entry
    due_date = datetime.utcnow() + timedelta(days=14)
    borrow = models.BorrowedBook(
        user_id=user_id,
        book_id=book_id,
        due_date=due_date
    )
    db.add(borrow)

    # 5. Update book copies
    book.copies_available -= 1

    db.commit()
    db.refresh(borrow)
    return borrow
