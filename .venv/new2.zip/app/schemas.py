# app/schemas.py

from pydantic import BaseModel, EmailStr
from datetime import datetime

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str  # 'student' or 'faculty'

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: str
    #access_token: str

    class Config:
        orm_mode = True

class Token(BaseModel):
    access_token: str
    token_type: str


class BorrowRequest(BaseModel):
    book_id: int

class BorrowedBookOut(BaseModel):
    id: int
    book_id: int
    user_id: int
    borrow_date: datetime
    due_date: datetime

    class Config:
        orm_mode = True